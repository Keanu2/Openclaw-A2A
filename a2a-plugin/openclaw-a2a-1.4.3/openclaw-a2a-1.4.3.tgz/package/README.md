# Openclaw-A2A

OpenClaw 的 **A2A Gateway** 插件（嵌入 Tunnel 版）：让两台设备上的 Agent 通过 A2A 互通，并在跨 NAT 时走云端中继转发。

| 项 | 值 |
|----|-----|
| 仓库目录 | `Openclaw-A2A` |
| npm 包名 | `openclaw-a2a` |
| 插件 ID | `a2a-gateway` |
| 当前版本 | `1.4.3` |

## 能做什么

- Agent ↔ Agent 消息与本地文件传输（默认内联上限 50MB）
- 可选嵌入隧道客户端，跨 NAT 经中继互通
- 可选注册中心自动发现对端

## 快速开始

```powershell
# 鸿蒙设备（主路径）：发布目录里的 tgz + 安装脚本
cd D:\openclaw\Openclaw-A2A\openclaw-a2a-1.4.3
.\install-to-harmony-device.ps1 -Serial <hdc序列号> -Tarball .\openclaw-a2a-1.4.3.tgz
```

详见 [INSTALL.md](./INSTALL.md) / 发布目录内同名说明。版本号与 `package.json` 均为 **`1.4.3`**。

## 文档

| 文档 | 说明 |
|------|------|
| [INSTALL.md](./INSTALL.md) | **安装包**安装说明、功能特性、配置与用例（随 tgz 分发） |
| [docs/安装包与配置说明.md](./docs/安装包与配置说明.md) | 安装包文档索引 |
| [docs/操作手册.md](./docs/操作手册.md) | 安装、直连 / NAT、注册中心、配置与排障 |
| [docs/源码修改说明.md](./docs/源码修改说明.md) | 相对上游的主要源码增量 |
| [docs/COMPATIBILITY.md](./docs/COMPATIBILITY.md) | A2A 兼容性说明 |
| [CHANGELOG.md](./CHANGELOG.md) | 版本变更 |

本地文件名规则（摘要）：发送侧传输名 = `path` 的 basename；线上 FilePart 为 `{ name, mimeType, bytes }`。详见操作手册与源码修改说明。

## License

MIT
